Real world examples from http://www.ferc.gov/docs-filing/eqr/soft-tools/sample-csv.asp
